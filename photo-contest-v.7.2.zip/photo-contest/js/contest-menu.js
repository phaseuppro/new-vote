(function ( $ ) {
	"use strict";

	$(function () {

		//Add datepicker for contest start
    $('.contest-start').datepicker();
    //Add datepicker for contest end
    $('.contest-end').datepicker();	
    
	});

}(jQuery));