<table id="table_units" class="display">
    <thead>
        <tr>
            <th></th>            
            <th><?php echo __('Thumb', 'fv') ?></th>            
            <th><?php echo __('Name', 'fv') ?></th>
            <th><?php echo __('Description', 'fv') ?></th>
            <th><?php echo __('Votes count', 'fv') ?></th>
            <th><?php echo __('Upload info', 'fv') ?></th>
            <th><?php echo __('User email', 'fv') ?></th>
            <th><?php echo __('User id', 'fv') ?></th>
            <th><?php echo __('User ip', 'fv') ?></th>
            <th><?php echo __('Status', 'fv') ?></th>
            <th><?php echo __('Added', 'fv') ?></th>
            <th><?php echo __('Actions', 'fv') ?></th>
        </tr>
    </thead>
    <tbody>
    <?php
    $competitors = $contest->getCompetitors(false, false, false, false, true, true);
    foreach ($competitors as $unit) :
        include '_table_units_tr.php';
    endforeach;
    ?>
    </tbody>
</table>

<strong>Mass actions with Selected rows:</strong>
<select class="fv-mass-actions-select">
    <option value=""> == Select action == </option>
    <option value="delete">Delete</option>
    <option value="rotate-right">Rotate right</option>
    <option value="rotate-left">Rotate left</option>
</select>
<br/><br/>