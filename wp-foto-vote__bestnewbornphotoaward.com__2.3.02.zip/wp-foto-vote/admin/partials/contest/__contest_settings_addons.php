<?php

echo FV_Admin_Contest_Meta_Helper::instance()->render_meta_fields( $contest, true );
