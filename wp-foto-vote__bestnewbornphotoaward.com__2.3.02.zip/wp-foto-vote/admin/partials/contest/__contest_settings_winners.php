<?php

echo FV_Admin_Contest_Config_Helper::instance()->get_section_with_fields_html('winners', $contest );