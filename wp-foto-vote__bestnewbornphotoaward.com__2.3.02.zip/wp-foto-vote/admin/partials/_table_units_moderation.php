<table id="table_units" class="display">
    <thead>
        <tr>
            <th></th>
            <th><?php echo __('Thumb', 'fv') ?></th>
            <th><?php echo __('Name', 'fv') ?></th>
            <th><?php echo __('Contest', 'fv') ?></th>
            <th><?php echo __('Upload info', 'fv') ?></th>
            <th><?php echo __('User email', 'fv') ?></th>
            <th><?php echo __('User id', 'fv') ?></th>
            <th><?php echo __('User ip', 'fv') ?></th>
            <th><?php echo __('Added (d/m/y)', 'fv') ?></th>
            <th><?php echo __('Action', 'fv') ?></th>
        </tr>
    </thead>
    <tfoot>
    <tr>
        <th></th>
        <th><?php echo __('Thumb', 'fv') ?></th>
        <th><?php echo __('Name', 'fv') ?></th>
        <th><?php echo __('Contest', 'fv') ?></th>
        <th><?php echo __('Upload info', 'fv') ?></th>
        <th><?php echo __('User email', 'fv') ?></th>
        <th><?php echo __('User id', 'fv') ?></th>
        <th><?php echo __('User ip', 'fv') ?></th>
        <th><?php echo __('Added (d/m/y)', 'fv') ?></th>
        <th><?php echo __('Action', 'fv') ?></th>
    </tr>
    </tfoot>
    <tbody>
    <?php
    foreach ($items as $unit) :
        ?>
        <tr class="status<?php echo $unit->status; ?>" data-id="<?php echo $unit->id; ?>">
            <td class="selected-checkbox"></td>
            <td data-order="<?php echo $unit->added_date; ?>" class="centered">
                <a href="<?php echo $unit->url; ?>" target="_blank"><img data-src="<?php echo $unit->getThumbUrl(); ?>" width="80" class="fv-table-thumb"/></a>
                <?php do_action('fv/admin/moderation/list_item/extra', $unit); ?>
            </td>            
            <td class="name"><?php echo $unit->name; ?></td>
            <td class="Contest"><?php echo $unit->contest_name; ?></td>
            <td class="upload_info"><?php echo FvFunctions::showUploadInfo($unit->upload_info), $unit->meta->get_custom_all_as_string(); ?></td>
            <td class="user_email"><?php echo $unit->user_email; ?></td>
            <td class="user_id"><?php echo $unit->user_id; ?></td>
            <td class="user_ip">
                <a href="http://www.ip-tracker.org/locator/ip-lookup.php?ip=<?php echo $unit->user_ip ?>" target="_blank"><?php echo $unit->user_ip ?></a>
            </td>
            <td class="date" data-order="<?php echo $unit->added_date; ?>"><?php echo date('d/m/Y',$unit->added_date); ?></td>
            <td class="actions">
                <a href="#" data-action="approve" data-call="Competitor.approve" data-competitor="<?php echo $unit->id; ?>" data-nonce="<?php echo wp_create_nonce('fv_competitor_approve_nonce') ?>"><?php _e('Approve', 'fv') ?></a><br/>
                <a href="#" data-call="Competitor.approve" data-need-comment="yes" data-competitor="<?php echo $unit->id; ?>" data-nonce="<?php echo wp_create_nonce('fv_competitor_approve_nonce') ?>"><?php _e('Approve with Comment', 'fv') ?></a><br/>
                <a href="#" data-action="delete" data-confirmation="yes" data-call="Competitor.delete" data-competitor="<?php echo $unit->id; ?>" data-nonce="<?php echo wp_create_nonce('fv_competitor_delete_nonce') ?>"><?php _e('Delete', 'fv') ?></a><br/>
                <a href="#" data-confirmation="yes" data-call="Competitor.delete" data-need-comment="yes" data-competitor="<?php echo $unit->id; ?>" data-nonce="<?php echo wp_create_nonce('fv_competitor_delete_nonce') ?>"><?php _e('Delete with Comment', 'fv') ?></a>
            </td>
        </tr>
    <?php endforeach; ?>        
    </tbody>
</table>

<strong>Mass actions with Selected rows:</strong>
<select class="fv-mass-actions-select">
    <option value=""> == Select action == </option>
    <option value="approve">Approve</option>
    <option value="delete">Delete</option>
</select>