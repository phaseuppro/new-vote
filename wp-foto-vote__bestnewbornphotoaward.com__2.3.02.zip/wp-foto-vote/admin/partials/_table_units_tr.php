<?php
    /*
     ** Params $unit - contestant item
     */
    /** @var FV_Competitor $unit */
    //$image_src = ($unit->image_id)? wp_get_attachment_image_src($unit->image_id) : '';
    $image_src = FvFunctions::getPhotoThumbnailArr($unit);
    $img_class = '';
    if ( isset($image_src[4]) ) {
        $img_class= $image_src[4];
    } elseif ( isset($unit->options['provider']) ) {
        $img_class = $unit->options['provider'];
    }
?>
        <tr class="id<?php echo $unit->id ?> status<?php echo $unit->status ?> <?php echo ( isset($edit) )? 'edited' : ''; ?>" data-id="<?php echo $unit->id; ?>">
            <td class="selected-checkbox"></td>
            <td class="img <?php echo $img_class ?>" data-order="<?php echo $unit->added_date; ?>">
                <a href="<?php echo FvFunctions::getPhotoFull($unit); ?>" target="_blank">
                    <?php if (defined('DOING_AJAX') && DOING_AJAX) : ?>
                        <img data-src="<?php echo ( is_array($image_src) )? $image_src[0] : ''; ?>" src="<?php echo ( is_array($image_src) )? $image_src[0] : ''; ?>" width="55" class="fv-table-thumb" />
                    <?php else: ?>
                        <img data-src="<?php echo ( is_array($image_src) )? $image_src[0] : ''; ?>" width="55" class="fv-table-thumb" />
                    <?php endif; ?>
                </a>
                <?php if ($unit->place): ?>
                    <div class="is-winner"><i class="fvicon-trophy3"></i> <strong><?php echo $unit->getPlaceCaption(); ?></strong></div>
                <?php endif; ?>
                <?php do_action('fv/admin/contestant/extra', $unit); ?>
            </td>
            <td class="name"><?php echo $unit->name ?></td>
            <td class="description"><?php echo $unit->description ?></td>
            <td class="votes_count" title="<?php echo $unit->votes_count, ' / fail : ' , $unit->votes_count_fail; ?>"><?php echo fv_get_votes($unit, false, false, true); ?></td>
            <td class="upload_info"><?php echo FvFunctions::showUploadInfo($unit->upload_info), $unit->meta()->get_custom_all_as_string(); ?></td>
            <td class="user_email"><?php echo $unit->getAuthorEmail(); ?></td>
            <td class="user_id"><a href="<?php echo admin_url('user-edit.php?user_id='.$unit->user_id) ?>" target="_blank"><?php echo $unit->user_id ?></a></td>
            <td class="user_ip"><?php echo $unit->user_ip ?></td>
            <td><?php echo __(fv_get_status_name($unit->status), 'fv') ?></td>
            <td class="added" data-order="<?php echo $unit->added_date; ?>"><?php echo date('d/m/Y',$unit->added_date) ?></td>
            <td class="actions">
                <a href="#<?php echo $unit->id ?>" data-call="Competitor.singleForm" data-contest="<?php echo $contest->id; ?>" data-competitor="<?php echo $unit->id; ?>" data-nonce="<?php echo wp_create_nonce('fv_nonce') ?>"><?php _e('Edit', 'fv') ?></a>
                / <a href="#<?php echo $unit->id ?>" data-action="delete" data-confirmation="yes" data-call="Competitor.delete" data-competitor="<?php echo $unit->id; ?>" data-nonce="<?php echo wp_create_nonce('fv_competitor_delete_nonce') ?>"><?php _e('Delete', 'fv') ?></a>
                /
                <a href="#<?php echo $unit->id ?>" data-call="Competitor.moveModal" data-contestant="<?php echo $unit->id; ?>" data-nonce="<?php echo wp_create_nonce('fv_nonce') ?>" title="Move to another contest">
                    <span class="dashicons dashicons-migrate"></span>
                </a>
                <?php if ( $unit->image_id ): ?>
                    <a href="<?php echo admin_url("post.php?post={$unit->image_id}&action=edit") ; ?>" target="_blank" title="edit attachment"><span class="dashicons dashicons-format-image"></span></a>
                <?php endif; ?>
                <br/>
                <a href="#0" data-action="rotate-right" data-confirmation="yes" title="<?php _e("rotate right", 'fv') ?>" onclick="fv_rotate_image(this, 270, <?php echo $unit->contest_id ?>, <?php echo $unit->id ?>, '<?php echo wp_create_nonce('fv_nonce') ?>'); return false;"><span class="dashicons dashicons-imgedit-rright rotate_img"></span></a>

                <a href="#0" data-action="rotate-left" data-confirmation="yes" title="<?php _e("rotate left", 'fv') ?>" onclick="fv_rotate_image(this, 90, <?php echo $unit->contest_id ?>, <?php echo $unit->id ?>, '<?php echo wp_create_nonce('fv_nonce') ?>'); return false;"><span class="dashicons dashicons-imgedit-rleft rotate_img"></span></a>
            </td>
        </tr>