var node_base = "D:\\wp-pluigns\\node_modules\\";
// ## Globals
// GULP variable declarations
var gulp = require('gulp'),
    //gutil = require(node_base+'gulp-util'),
    autoprefixer = require(node_base+'gulp-autoprefixer'),
    cleanCSS = require(node_base+'gulp-clean-css'),
    rename = require(node_base+'gulp-rename'),
    concat = require(node_base+'gulp-concat'),
    del = require(node_base+'del');
    uglify = require(node_base+'gulp-uglify');


// File path variable declarations
var stylePath = "";
var scriptPath = "";

gulp.task('fv-minify-js', function(callback) {
    gulp.start('compile-main-js');
    gulp.start('compile-modal-js');
    gulp.start('compile-lib-js');
    gulp.start('compile-upload-js');
    gulp.start('compile-lib-imageLightbox');
    gulp.start('compile-lib-evercookie');
    gulp.start('compile-lib-jquery-unveil');
    gulp.start('compile-lib-countdown-default');
    gulp.start('compile-lib-countdown-final');
});


gulp.task('fv-minify-css', function(callback) {
    gulp.start('compile-imageLightbox');
    gulp.start('compile-main-css');
    //gulp.start('complie-font-css');
});

gulp.task('fv-minify', ['fv-minify-js', 'fv-minify-css'] );

// Process imageLightbox css
gulp.task('compile-imageLightbox', function() {
    del(['assets/image-lightbox/jquery.image-lightbox.min.css']);

    return gulp.src('assets/image-lightbox/jquery.image-lightbox.css')
        .pipe(concat('jquery.image-lightbox.css'))
        .pipe(rename({suffix: '.min'}))
        .pipe(autoprefixer({
            browsers: [
                'last 2 versions',
                'ie 8',
                'ie 9',
                'android 2.3',
                'android 4',
                'opera 12'
            ]
        }))
        .pipe(cleanCSS())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});

// Process MAIN css
gulp.task('compile-main-css', function() {
    del(['assets/css/fv_main.min.css']);

    return gulp.src('assets/css/fv_main.css')
        .pipe(concat('fv_main.css'))
        .pipe(rename({suffix: '.min'}))
        .pipe(autoprefixer({
            browsers: [
                'last 2 versions',
                'ie 8',
                'ie 9',
                'android 2.3',
                'android 4',
                'opera 12'
            ]
        }))
        .pipe(cleanCSS({keepSpecialComments :1, advanced: true}))
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});


// Process  JS
gulp.task('compile-main-js', function() {
    del(['assets/js/fv_main.min.js']);

    return gulp.src('assets/js/fv_main.js')
        .pipe(concat('fv_main.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});

gulp.task('compile-modal-js', function() {
    del(['assets/js/fv_modal.min.js']);

    return gulp.src('assets/js/fv_modal.js')
        .pipe(concat('fv_modal.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});
gulp.task('compile-upload-js', function() {
    del(['assets/js/fv_upload.min.js']);

    return gulp.src('assets/js/fv_upload.js')
        .pipe(concat('fv_upload.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});
gulp.task('compile-lib-js', function() {
    del(['assets/js/fv_lib.min.js']);

    return gulp.src('assets/js/fv_lib.js')
        .pipe(concat('fv_lib.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});
gulp.task('compile-lib-evercookie', function() {
    del(['assets/evercookie/js/evercookie.min.js']);

    return gulp.src('assets/evercookie/js/evercookie.js')
        .pipe(concat('evercookie.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});
gulp.task('compile-lib-imageLightbox', function() {
    del(['assets/image-lightbox/jquery.image-lightbox.min.js']);

    return gulp.src('assets/image-lightbox/jquery.image-lightbox.js')
        .pipe(concat('jquery.image-lightbox.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});
gulp.task('compile-lib-jquery-unveil', function() {
    del(['assets/vendor/jquery.unveil.min.js']);

    return gulp.src('assets/vendor/jquery.unveil.js')
        .pipe(concat('jquery.unveil.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});

gulp.task('compile-lib-countdown-default', function() {
    del(['addons/coutdown-deafult/assets/fv-countdown-default.min.js']);

    return gulp.src('addons/coutdown-deafult/assets/fv-countdown-default.js')
        .pipe(concat('fv-countdown-default.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});

gulp.task('compile-lib-countdown-final', function() {
    del(['addons/final-countdown/assets/fv-final-countdown.min.js']);

    return gulp.src('addons/final-countdown/assets/fv-final-countdown.js')
        .pipe(concat('fv-final-countdown.js'))
        .pipe(rename({suffix: '.min'}))
        .pipe(uglify())
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});

/*
// Process FONTS css
gulp.task('complie-font-css', function() {
    del(['assets/icommon/fv_fonts.min.css']);

    return gulp.src('assets/icommon/fv_fonts.css')
        .pipe(concat('fv_fonts.css'))
        .pipe(rename({suffix: '.min'}))
        .pipe(cleanCSS({keepSpecialComments :1}))
        .pipe(gulp.dest(function(file) {
            return file.base;
        }));
});
*/
/*
// ### Gulp
// `gulp` - Run a complete build. To compile for production run `gulp --production`.
gulp.task('default', ['complie-imageLightbox'], function() {
    gulp.start('build');
});
*/
