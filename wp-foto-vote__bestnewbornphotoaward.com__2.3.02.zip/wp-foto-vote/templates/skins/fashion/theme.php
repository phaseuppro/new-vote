<?php
// http://vnjs.net/www/project/freewall/

// if not Infinite pagination and AJAX action
if ( defined('DOING_AJAX') && DOING_AJAX == TRUE && fv_setting('pagination-type', 'default') == 'infinite' ) {
    return;
}
