<?php

// You php code here
// * It will runs just on contest page
