<?php
/**
 * Fired during plugin deactivation.
 *
 * @since      2.2.503
 * @package    FV
 * @subpackage FV/includes
 * @author     Maxim K <support@wp-vote.net>
 */
class FV_Deactivator {

	/**
	 * Add tables to database when plugin activates
	 *
	 * @since    2.2.503
	 */
	public static function deactivate() {
		FV_Cron::deregister();
		add_option('fv-schedule-flush_rewrite_rules', true);
	}

}
